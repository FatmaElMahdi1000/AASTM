All_grades = [56,78,93,42,97,85,34,67,73,86]

updated_list = []
for grade in All_grades:
    if grade > 50:
        updated_list.append(grade)
print(updated_list)
